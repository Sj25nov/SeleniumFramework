package ex_23022026HandleFileUploadScrollingPageJavascriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class ScrollPageBYJavaScripts_Bottom {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://testautomationpractice.blogspot.com/");
        driver.manage().window().maximize();

        JavascriptExecutor Js=(JavascriptExecutor)driver;

        Js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        System.out.println(Js.executeScript("return window.pageYOffset;"));

    }
}
